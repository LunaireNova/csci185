function showFox() {
    // your code here...
    document.querySelector("#image-demo").src= "./images/fox.jpg"
    console.log('Change image and paragraph to fox...');
    document.querySelector("#textfield").innerText="Fox"
}

function showLion() {
    // your code here...
    document.querySelector("#image-demo").src= "./images/lion.jpg"
    console.log('Change image and paragraph to lion...');
    document.querySelector("#textfield").innerText="Lion"
}

function showTiger() {
    // your code here...
    document.querySelector("#image-demo").src= "./images/tiger.png"
    console.log('Change image and paragraph to tiger...');
    document.querySelector("#textfield").innerText="Tiger"
}

function showZebra() {
    document.querySelector("#image-demo").src= "./images/zebra.jpg"
    // your code here...
    console.log('Change image and paragraph to zebra...');
    document.querySelector("#textfield").innerText="Zebra"
}

